from setuptools import setup

setup(name='nd_probability',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['nd_probability'],
      author='Nachiket Dixit',
      author_email='nachiket.dixit@gmail.com',
      zip_safe=False)
